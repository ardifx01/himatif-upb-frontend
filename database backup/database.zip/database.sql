-- --------------------------------------------------------
-- Host:                         localhost
-- Versi server:                 8.0.30 - MySQL Community Server - GPL
-- OS Server:                    Win64
-- HeidiSQL Versi:               12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Membuang struktur basisdata untuk db_himatif
CREATE DATABASE IF NOT EXISTS `db_himatif` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db_himatif`;

-- membuang struktur untuk table db_himatif.banner
CREATE TABLE IF NOT EXISTS `banner` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `priority` tinyint(1) NOT NULL,
  `imageUrl` varchar(255) DEFAULT NULL,
  `userId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `banner_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_10` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_11` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_12` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_13` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_14` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_15` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_3` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_5` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_6` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_7` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_8` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `banner_ibfk_9` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel db_himatif.banner: ~0 rows (lebih kurang)
REPLACE INTO `banner` (`id`, `title`, `uploadDate`, `priority`, `imageUrl`, `userId`, `createdAt`, `updatedAt`) VALUES
	(1, 'Banner1', '2024-11-20 09:33:06', 1, '/uploads/1732095186837-1589165051228.jpg', 1, '2024-11-20 09:33:06', '2024-11-20 09:33:06'),
	(2, 'Banner1', '2024-11-20 09:33:28', 1, '/uploads/1732095208043-1589165051228.jpg', 1, '2024-11-20 09:33:28', '2024-11-20 09:33:28'),
	(3, 'Banner1', '2024-11-20 09:33:43', 1, '/uploads/1732095223408-toyoindo.jpg', 1, '2024-11-20 09:33:43', '2024-11-20 09:33:43'),
	(4, 'Banner1', '2024-11-20 09:34:13', 0, '/uploads/1732095253109-toyoindo.jpg', 1, '2024-11-20 09:34:13', '2024-11-20 09:34:13');

-- membuang struktur untuk table db_himatif.content
CREATE TABLE IF NOT EXISTS `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `label` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `content_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_10` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_11` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_12` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_13` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_14` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_15` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_16` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_17` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_18` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_19` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_20` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_21` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_22` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_23` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_24` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_25` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_26` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_27` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_28` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_29` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_3` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_30` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_31` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_32` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_33` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_5` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_6` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_7` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_8` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `content_ibfk_9` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel db_himatif.content: ~0 rows (lebih kurang)

-- membuang struktur untuk table db_himatif.departement
CREATE TABLE IF NOT EXISTS `departement` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `proker` varchar(255) DEFAULT NULL,
  `updateDate` datetime DEFAULT NULL,
  `userId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `departement_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_10` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_11` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_12` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_13` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_14` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_15` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_3` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_5` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_6` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_7` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_8` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `departement_ibfk_9` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel db_himatif.departement: ~5 rows (lebih kurang)
REPLACE INTO `departement` (`id`, `name`, `description`, `proker`, `updateDate`, `userId`, `createdAt`, `updatedAt`) VALUES
	(1, 'Pengembangan Organisasi', 'Mengelola dan meningkatkan efektivitas struktur organisasi serta pengembangan kapasitas anggota.', 'Mengadakan pelatihan kepemimpinan, menyusun struktur organisasi yang efektif, serta melaksanakan evaluasi kinerja organisasi.', '2024-11-20 06:21:20', 1, '2024-11-20 06:21:20', '2024-11-20 07:15:46'),
	(2, 'Hubungan Internal dan External', 'Bertanggung jawab atas pengelolaan hubungan dengan pihak internal organisasi serta pihak eksternal seperti mitra, sponsor, dan pihak terkait lainnya.', 'Mengadakan kegiatan networking, menjalin kemitraan dengan pihak eksternal, dan menyelenggarakan acara kolaborasi antar organisasi.', '2024-11-20 07:15:10', 1, '2024-11-20 07:15:10', '2024-11-20 07:15:10'),
	(3, 'Penelitian dan Pengembangan', 'Berfokus pada eksplorasi, penelitian, dan pengembangan ide-ide baru untuk kemajuan organisasi.', 'Melakukan survei dan analisis kebutuhan anggota, mengembangkan inovasi program kerja, serta menyusun kajian strategis untuk kemajuan organisasi.', '2024-11-20 07:15:17', 1, '2024-11-20 07:15:17', '2024-11-20 07:15:17'),
	(4, 'Media Komunikasi dan Informasi', 'Mengelola komunikasi organisasi melalui media sosial dan kanal informasi untuk meningkatkan visibilitas dan interaksi.', 'Membuat konten media sosial, menyusun buletin organisasi, serta menyelenggarakan kampanye online untuk mempromosikan program kerja organisasi.', '2024-11-20 07:15:27', 1, '2024-11-20 07:15:27', '2024-11-20 07:15:27'),
	(5, 'Minat dan Bakat', 'Mewadahi dan mendukung pengembangan minat serta bakat anggota organisasi melalui berbagai kegiatan kreatif.', 'Menyelenggarakan pelatihan keterampilan, mengadakan kompetisi internal, serta mendukung partisipasi anggota dalam kompetisi eksternal.', '2024-11-20 07:15:37', 1, '2024-11-20 07:15:37', '2024-11-20 07:15:37');

-- membuang struktur untuk table db_himatif.galery
CREATE TABLE IF NOT EXISTS `galery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `departement` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `imageUrl` varchar(255) DEFAULT NULL,
  `userId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `galery_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_10` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_11` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_12` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_13` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_14` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_3` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_5` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_6` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_7` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_8` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `galery_ibfk_9` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel db_himatif.galery: ~10 rows (lebih kurang)
REPLACE INTO `galery` (`id`, `title`, `departement`, `description`, `uploadDate`, `imageUrl`, `userId`, `createdAt`, `updatedAt`) VALUES
	(14, 'Study Bunding', 'Pengembangan Organisasi', 'Study Bunding', '2024-11-21 01:31:54', '/uploads/1732152714165-PO - Study Banding.JPG', 1, '2024-11-21 01:31:54', '2024-11-21 01:31:54'),
	(15, 'ITBC', 'Pengembangan Organisasi', 'ITBC', '2024-11-21 01:32:36', '/uploads/1732152756686-PO - ITBC.jpg', 1, '2024-11-21 01:32:36', '2024-11-21 01:32:36'),
	(16, 'Follow Up & Up Grading', 'Pengembangan Organisasi', 'Follow Up & Up Grading', '2024-11-21 01:33:16', '/uploads/1732152796776-PO - Follow Up & Up Grading.jpg', 1, '2024-11-21 01:33:16', '2024-11-21 01:33:16'),
	(17, 'Seminar Nasional', 'Media Komunikasi dan Informasi', 'Seminar Nasional', '2024-11-21 01:34:24', '/uploads/1732152864765-Medkom - Seminar Nasional.jpg', 1, '2024-11-21 01:34:24', '2024-11-21 01:34:24'),
	(18, 'Mini Course', 'Media Komunikasi dan Informasi', 'Mini Course', '2024-11-21 01:35:00', '/uploads/1732152900350-Medkom - MiniCourse.JPG', 1, '2024-11-21 01:35:00', '2024-11-21 01:35:00'),
	(19, 'Skill Forge', 'Penelitian dan Pengembangan', 'Skill Forge', '2024-11-21 01:39:17', '/uploads/1732153157066-Litbang - Skill Forge.jpg', 1, '2024-11-21 01:39:17', '2024-11-21 01:39:17'),
	(20, 'Himatif Berkah Ramadhan', 'Hubungan Internal dan External', 'Himatif Berkah Ramadhan', '2024-11-21 01:40:20', '/uploads/1732153220528-Hubineks - Himatif Berkah Ramadhan.jpg', 1, '2024-11-21 01:40:20', '2024-11-21 01:40:20'),
	(21, 'Dies Natalis', 'Hubungan Internal dan External', 'Dies Natalis', '2024-11-21 01:41:00', '/uploads/1732153260608-Hubineks - Diesnat.JPG', 1, '2024-11-21 01:41:00', '2024-11-21 01:41:00'),
	(22, 'Bakti Desa', 'Hubungan Internal dan External', 'Bakti Desa', '2024-11-21 01:43:26', '/uploads/1732153406189-Hubineks - Bakti Desa.jpg', 1, '2024-11-21 01:43:26', '2024-11-21 01:43:26'),
	(23, 'Fast', 'Himatif', 'Fast', '2024-11-21 01:44:10', '/uploads/1732153450214-Fast.JPG', 1, '2024-11-21 01:44:10', '2024-11-21 01:44:10'),
	(24, 'HimScope', 'Himatif', 'HimScope', '2024-11-21 01:45:21', '/uploads/1732153521230-Himscope (Small).jpg', 1, '2024-11-21 01:45:21', '2024-11-21 01:45:21');

-- membuang struktur untuk table db_himatif.history
CREATE TABLE IF NOT EXISTS `history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `updateDate` datetime DEFAULT NULL,
  `userId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `history_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_10` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_11` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_12` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_13` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_14` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_15` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_16` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_17` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_18` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_19` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_20` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_21` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_3` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_5` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_6` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_7` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_8` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `history_ibfk_9` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel db_himatif.history: ~0 rows (lebih kurang)
REPLACE INTO `history` (`id`, `title`, `content`, `updateDate`, `userId`, `createdAt`, `updatedAt`) VALUES
	(1, '2016 – Pendirian HIMATIF di STT Pelita Bangsa', 'Pada tanggal 22 Mei 2016, HIMATIF resmi didirikan di Sekolah Tinggi Teknologi (STT) Pelita Bangsa. Organisasi ini lahir dari gagasan Badan Eksekutif Mahasiswa (BEM) STT Pelita Bangsa yang ingin menyediakan wadah bagi mahasiswa jurusan Teknik Informatika untuk mengembangkan potensi, bakat, dan minat di bidang teknologi informasi. HIMATIF bertujuan untuk membangun lingkungan yang kondusif bagi mahasiswa untuk saling berbagi pengetahuan, pengalaman, serta mengadakan kegiatan yang bermanfaat dalam bidang akademik dan teknologi, seperti seminar, workshop, dan kompetisi. Sejak awal berdiri, HIMATIF memiliki peran penting sebagai tempat bagi mahasiswa Teknik Informatika untuk memperdalam ilmu, menjalin relasi, dan mengenalkan dunia IT di lingkungan kampus dan masyarakat luas. Organisasi ini juga menjadi sarana bagi mahasiswa untuk mengasah keterampilan kepemimpinan, kerja sama, serta pengembangan diri melalui berbagai program yang diinisiasi oleh pengurus dan anggota HIMATIF.', '2024-11-20 08:26:11', 1, '2024-11-20 08:26:11', '2024-11-20 08:26:11'),
	(2, '2017 – Konsolidasi Organisasi dan Pengembangan Program Kerja', 'Pada tahun 2017, HIMATIF mulai memperkuat struktur organisasi dan mengembangkan berbagai program kerja yang lebih terarah. Organisasi ini memperluas kegiatan dengan mengadakan acara tahunan yang melibatkan mahasiswa Teknik Informatika dari berbagai angkatan. Program kerja yang dijalankan mencakup seminar teknologi, kompetisi pemrograman, serta kegiatan bakti sosial sebagai bentuk kontribusi HIMATIF kepada masyarakat. Selain itu, HIMATIF mulai membangun jaringan dengan organisasi mahasiswa lain, baik di dalam kampus maupun di luar kampus. Kolaborasi ini bertujuan untuk meningkatkan kualitas acara yang diadakan dan memberikan kesempatan kepada anggota HIMATIF untuk memperluas wawasan serta mengembangkan keterampilan interpersonal.', '2024-11-20 08:26:29', 1, '2024-11-20 08:26:29', '2024-11-20 08:26:29'),
	(3, '2018 – Peningkatan Kualitas dan Ekspansi Program', 'Pada tahun 2018, HIMATIF semakin aktif dalam mengadakan kegiatan yang mendukung pengembangan akademik dan teknis anggotanya. Di tahun ini, HIMATIF mengadakan berbagai pelatihan intensif di bidang pemrograman, pengembangan web, serta pengenalan teknologi baru yang relevan dengan dunia IT. HIMATIF juga mengadakan kegiatan kunjungan industri yang memberikan wawasan langsung kepada mahasiswa mengenai dunia kerja di bidang teknologi. Organisasi ini terus berkembang dengan meningkatkan kualitas kegiatan dan melibatkan pembicara atau mentor dari luar kampus. Langkah ini bertujuan untuk memberikan pengalaman yang lebih kaya kepada anggota HIMATIF, serta membangun reputasi organisasi sebagai wadah yang aktif dan profesional di kalangan mahasiswa.', '2024-11-20 08:26:36', 1, '2024-11-20 08:26:36', '2024-11-20 08:26:36'),
	(4, '2019 – Memperkuat Kolaborasi dan Kemitraan Eksternal', 'Pada tahun 2019, HIMATIF memperkuat kolaborasi dengan industri dan lembaga-lembaga pendidikan. HIMATIF menjalin kerja sama dengan perusahaan teknologi dan menghadirkan pelatihan-pelatihan yang didukung oleh para praktisi profesional. Dengan semakin meningkatnya tuntutan dunia kerja terhadap lulusan IT yang kompeten, HIMATIF terus berupaya membekali anggotanya dengan pengetahuan dan keterampilan yang sesuai dengan perkembangan teknologi terbaru.', '2024-11-20 08:26:43', 1, '2024-11-20 08:26:43', '2024-11-20 08:26:43'),
	(5, '2020 – Transformasi Menjadi HIMATIF Universitas Pelita Bangsa', 'Pada tanggal 29 Februari 2020, HIMATIF mengalami perubahan signifikan seiring dengan perubahan status STT Pelita Bangsa menjadi Universitas Pelita Bangsa. HIMATIF pun berubah nama menjadi HIMATIF Universitas Pelita Bangsa. Perubahan ini tidak hanya sekadar perubahan nama, tetapi juga menjadi momentum penting untuk memperluas cakupan kegiatannya serta memperkuat eksistensinya di lingkungan akademik yang lebih besar. Dengan status baru sebagai bagian dari universitas, HIMATIF memiliki tanggung jawab yang lebih besar dalam mengakomodasi kebutuhan mahasiswa, baik dalam hal pengembangan keahlian teknologi, riset, maupun soft skills. Organisasi ini semakin intensif dalam mengadakan kegiatan-kegiatan yang mendukung peningkatan kompetensi mahasiswa di bidang teknologi informasi.', '2024-11-20 08:26:49', 1, '2024-11-20 08:26:49', '2024-11-20 08:26:49'),
	(6, '2024 – Transformasi Digital dan Pembangunan Website', 'Pada tahun 2024, HIMATIF Universitas Pelita Bangsa melangkah lebih jauh dalam upaya transformasi digital untuk memperkuat kehadirannya di dunia maya dan mempermudah akses informasi bagi anggotanya. Tahun ini, HIMATIF berhasil membangun dan meluncurkan website resmi organisasi yang berfungsi sebagai platform utama untuk menginformasikan kegiatan, program kerja, dan berita terkini yang berkaitan dengan HIMATIF. Selain itu, website ini menyediakan akses ke berbagai materi edukatif dan tutorial teknologi, yang bertujuan untuk meningkatkan kemampuan teknis anggota HIMATIF. Pembangunan website ini juga mencakup integrasi dengan sistem manajemen organisasi yang memudahkan pengurus dalam mengelola data, dokumentasi kegiatan, serta komunikasi dengan anggota secara digital. Transformasi digital ini diharapkan dapat memperkuat eksistensi HIMATIF sebagai organisasi yang adaptif dan selaras dengan perkembangan teknologi informasi.', '2024-11-20 08:26:55', 1, '2024-11-20 08:26:55', '2024-11-20 08:26:55');

-- membuang struktur untuk table db_himatif.news
CREATE TABLE IF NOT EXISTS `news` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `uploader` varchar(255) NOT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `imageUrl` varchar(255) DEFAULT NULL,
  `userId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `news_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_10` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_11` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_12` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_13` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_14` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_15` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_16` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_17` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_18` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_19` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_20` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_21` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_22` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_23` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_24` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_3` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_5` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_6` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_7` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_8` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_ibfk_9` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel db_himatif.news: ~0 rows (lebih kurang)

-- membuang struktur untuk table db_himatif.profile
CREATE TABLE IF NOT EXISTS `profile` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `updateDate` datetime DEFAULT NULL,
  `userId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `profile_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_10` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_11` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_12` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_13` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_14` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_15` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_16` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_17` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_18` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_19` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_20` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_21` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_22` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_3` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_5` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_6` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_7` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_8` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `profile_ibfk_9` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel db_himatif.profile: ~0 rows (lebih kurang)
REPLACE INTO `profile` (`id`, `title`, `body`, `updateDate`, `userId`, `createdAt`, `updatedAt`) VALUES
	(1, 'profile', 'HIMATIF (Himpunan Mahasiswa Teknik Informatika) Universitas Pelita Bangsa adalah organisasi mahasiswa yang berada di bawah naungan Program Studi Teknik Informatika. Sebagai wadah komunikasi, informasi, dan kolaborasi, HIMATIF hadir untuk membantu mahasiswa tidak hanya dalam memperdalam ilmu Teknik Informatika, tetapi juga dalam mengembangkan soft skills yang penting di era digital. <br/> <br/>  Dengan beragam kegiatan mulai dari seminar teknologi terbaru, workshop coding, hingga kompetisi IT, HIMATIF menciptakan lingkungan yang mendorong inovasi dan kolaborasi antar mahasiswa. Bergabung dengan HIMATIF berarti membuka pintu menuju pengalaman praktis, jaringan profesional, dan kesempatan untuk berkarya di dunia Teknologi Informasi yang terus berkembang.', '2024-11-20 06:09:52', 1, '2024-11-20 06:09:52', '2024-11-20 06:09:52');

-- membuang struktur untuk table db_himatif.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `username_2` (`username`),
  UNIQUE KEY `username_3` (`username`),
  UNIQUE KEY `username_4` (`username`),
  UNIQUE KEY `username_5` (`username`),
  UNIQUE KEY `username_6` (`username`),
  UNIQUE KEY `username_7` (`username`),
  UNIQUE KEY `username_8` (`username`),
  UNIQUE KEY `username_9` (`username`),
  UNIQUE KEY `username_10` (`username`),
  UNIQUE KEY `username_11` (`username`),
  UNIQUE KEY `username_12` (`username`),
  UNIQUE KEY `username_13` (`username`),
  UNIQUE KEY `username_14` (`username`),
  UNIQUE KEY `username_15` (`username`),
  UNIQUE KEY `username_16` (`username`),
  UNIQUE KEY `username_17` (`username`),
  UNIQUE KEY `username_18` (`username`),
  UNIQUE KEY `username_19` (`username`),
  UNIQUE KEY `username_20` (`username`),
  UNIQUE KEY `username_21` (`username`),
  UNIQUE KEY `username_22` (`username`),
  UNIQUE KEY `username_23` (`username`),
  UNIQUE KEY `username_24` (`username`),
  UNIQUE KEY `username_25` (`username`),
  UNIQUE KEY `username_26` (`username`),
  UNIQUE KEY `username_27` (`username`),
  UNIQUE KEY `username_28` (`username`),
  UNIQUE KEY `username_29` (`username`),
  UNIQUE KEY `username_30` (`username`),
  UNIQUE KEY `username_31` (`username`),
  UNIQUE KEY `username_32` (`username`),
  UNIQUE KEY `username_33` (`username`),
  UNIQUE KEY `username_34` (`username`),
  UNIQUE KEY `username_35` (`username`),
  UNIQUE KEY `username_36` (`username`),
  UNIQUE KEY `username_37` (`username`),
  UNIQUE KEY `username_38` (`username`),
  UNIQUE KEY `username_39` (`username`),
  UNIQUE KEY `username_40` (`username`),
  UNIQUE KEY `username_41` (`username`),
  UNIQUE KEY `username_42` (`username`),
  UNIQUE KEY `username_43` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel db_himatif.user: ~0 rows (lebih kurang)
REPLACE INTO `user` (`id`, `username`, `name`, `password`, `createdAt`, `updatedAt`) VALUES
	(1, 'admin', 'Super Ali Admin', '$2a$10$2fksS1SE6BtFw4PV6lbx0.Zj3CjEqmloxTy3rAoOiosL4XDhj2WGm', '2024-11-20 06:04:38', '2024-11-20 06:04:38');

-- membuang struktur untuk table db_himatif.visimisi
CREATE TABLE IF NOT EXISTS `visimisi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `label` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `visimisi_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_10` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_11` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_12` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_13` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_14` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_15` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_16` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_17` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_18` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_19` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_20` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_21` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_22` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_23` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_24` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_25` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_26` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_27` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_28` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_29` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_3` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_4` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_5` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_6` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_7` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_8` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visimisi_ibfk_9` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Membuang data untuk tabel db_himatif.visimisi: ~0 rows (lebih kurang)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
